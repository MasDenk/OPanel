ActionMailer::Base.raise_delivery_errors = false
ActionMailer::Base.delivery_method = :sendmail
