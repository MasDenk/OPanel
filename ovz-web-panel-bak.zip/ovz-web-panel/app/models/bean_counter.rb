class BeanCounter < ActiveRecord::Base

  PERIOD_PERMANENT = 0
  PERIOD_MINUTE = 1

end
