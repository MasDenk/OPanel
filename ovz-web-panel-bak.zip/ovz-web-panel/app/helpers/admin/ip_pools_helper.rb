module Admin::IpPoolsHelper
end
