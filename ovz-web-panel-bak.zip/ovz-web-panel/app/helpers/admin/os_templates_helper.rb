module Admin::OsTemplatesHelper
end
