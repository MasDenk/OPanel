module Admin::ServerTemplatesHelper
end
