module Admin::SearchHelper
end
