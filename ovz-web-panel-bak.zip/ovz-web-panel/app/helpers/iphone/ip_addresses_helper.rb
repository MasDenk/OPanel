module Iphone::IpAddressesHelper
end
